/auth/users/
/auth/token/login/
/auth/token/logout/
/restaurant/booking/tables/
/restaurant/menu/items/
